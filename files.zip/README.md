# Backend
Maintainers:
[GGLVXD](https://github.com/GGLVXD)

## CC0 1.0 Universal (Public Domain Dedication)

This work has been dedicated to the public domain under the CC0 1.0 Universal license.

### What you CAN do:
- Copy, modify, distribute, and perform the work, even for commercial purposes, all without asking permission.
- Use the work for any purpose, including commercial and promotional purposes.
- Build upon, remix, or adapt the work and use it in new ways.

### What you CANNOT do:
- Claim any trademark or patent rights that might be associated with the work (if any exist).
- Expect any warranties for the work. It is provided “as-is,” with no guarantees about its quality or usability.

### Limitations:
- The original creator of the work does not guarantee that the work doesn’t infringe on others' rights.
- You are responsible for clearing any rights, such as image or likeness rights, that may apply to the work.

